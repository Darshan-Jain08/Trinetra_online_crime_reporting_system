<?php
	require '../database/dblib.php';
	function reports(){
		?>

		<?php
	}
	function slideShow(){
		?>
		<section id="slideshow">
					<div class="slideshow-container">
					<div class="mySlides fade">
					  <!--<div class="numbertext">1 / 3</div>-->
					  <img src="../images/thought.png" > 
					</div>
					<div class="mySlides fade">
					<!--<div class="numbertext">2 / 3</div>-->
					  <img src="../images/police.jpg" >
					</div>
					<div class="mySlides fade">
					 <!-- <div class="numbertext">3 / 3</div>-->
					  <img src="../images/crimescene.jpg" >
					</div>
					</div>
		</section>
		<?php
	}

?>