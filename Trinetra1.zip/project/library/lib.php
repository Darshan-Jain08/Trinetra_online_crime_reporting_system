<?php
function loginDiv($uname,$password){
	echo "<div class='modal1' id='loginr'>
					<form class='modal-content ' action=". $_SERVER['PHP_SELF']." method='post'>
						<div class='imgcontainer'>
							<span onclick=\"document.getElementById('loginr').style.display='none'\" class='close' title='Close Modal'>&times;</span>
						</div>
							<h2 align='center'>login</h2>
								<h4 align='center' style='color:red;'>Invalid username or password!!!</h4>
						<div class='container'>
							 <input type='text' name='uname' id='username' placeholder='Username' required autocomplete='off'  value=\"$uname\" >
						  <input type='password' name='password' id='password' placeholder='password'required value=\"$password\">
							<button name='btnlogin'>Login</button>
							<label>
								<input type='checkbox' id='show' onclick=\"showPassword()\">Show password
							</label>
						</div>
						<div class='container' style='background-color:#f1f1f1'>
							<span class='psw'> <a onclick=\"document.getElementById('frgtpsw').style.display='block'\" style='width:auto;'>Forgot password?</a></span>
							<span class='sgn'>Don't have an account? <a onclick=\"document.getElementById('signup').style.display='block'\" style='width:auto;'>Signup</a></span>
						</div>
					</form>
					</div>";
}
function signupDiv($uname,$moe,$fname,$password,$msg){
	echo "<div id='signupv' class='modal1'>
					  <form class='modal-content' action=".$_SERVER['PHP_SELF']." method='post' style='margin:auto'>
						<div class='imgcontainer'>
						   <span onclick=\"document.getElementById('signupv').style.display='none'\" class='rarr' >&larr;</span>
						</div>
						<h2 align='center'>Signup</h2>
						<h4 align='center' style='color:red;'>$msg</h4>
						<div class='container'>
						  <input type='text' name='mobile_no/email' placeholder='Mobile number or Email' required autocomplete='off' value=\"$moe\">
						  <input type='text' name='fullname' id='fullname' placeholder='Full Name' required autocomplete='off' value=\"$fname\">
						  <input type='text' name='uname' id='username' placeholder='Username' required autocomplete='off'  value=\"$uname\" >
						  <input type='password' name='password' id='password' placeholder='password'required value=\"$password\">
						  <button name='btnsignup'>signup</button>
						</div>
						<div class='container' style='background-color:#f1f1f1'>
						  <button type='button' onclick=\"document.getElementById('signupv').style.display='none'\" class='cancelbtn'>Cancel</button>
						</div>
					  </form>
					</div>";
}
function forgotPsw($uname,$moe,$msg){
	echo "<div id='frgpsw' class='modal1' >
					<form class='modal-content ' action=". $_SERVER['PHP_SELF']." method='post'>
						<div class='imgcontainer'>
							<span onclick=\"document.getElementById('frgpsw').style.display='none'\" class='close' title='Close Modal'>&times;</span>
						</div>
							<h2 align='center'>Forgot passowrd</h2>
							<h4 align='center' style='color:red;'>$msg</h4>
						<div class='container'>
							<input type='text' name='uname' id='username' placeholder='Username' required autocomplete='off'  value=\"$uname\" >
							<input type='text' name='mobile_no/email' placeholder='Mobile number or Email' required autocomplete='off' value=\"$moe\">
							<button name='btnfrgpsw'>Verify</button>	
						</div>
						<div class='container' style='background-color:#f1f1f1'>
						  <button type='button' onclick=\"document.getElementById('frgpsw').style.display='none'\" class='cancelbtn'>Cancel</button>
						</div>
					</form>
					</div>";
}
function forgotPswConf($uname,$moe,$msg){
	echo "<div id='frgpswcf' class='modal1' >
					<form class='modal-content' action=". $_SERVER['PHP_SELF']." method='post'>
						<div class='imgcontainer'>
							<span onclick=\"document.getElementById('frgpswcf').style.display='none'\" class='close' title='Close Modal'>&times;</span>
						</div>
							<h2 align='center'>Forgot password</h2>
							<h4 align='center' style='color:green;'>$msg</h4>
						<div class='container'>
							<input type='text' name='uname' id='username' placeholder='Username' required autocomplete='off'  value=\"$uname\" >
							<input type='text' name='mobile_no/email' placeholder='Mobile number or Email' required autocomplete='off' value=\"$moe\">
							<input type='password' name='password' id='password' placeholder='Enter New password'required >
							<label>
								<input type='checkbox' id='show' onclick=\"showPassword()\">Show password
							</label>
							<button name='btnfrgpswConf'>Change password</button>	
						</div>
						<div class='container' style='background-color:#f1f1f1'>
						  <button type='button' onclick=\"document.getElementById('frgpswcf').style.display='none'\" class='cancelbtn'>Cancel</button>
						</div>
					</form>
					</div>";
}
function signup($fname,$uname,$password,$mo,$email){
			require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(user_id) from user";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['max(user_id)'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				$sql = "insert into user values($counter,'$uname','$fname','$password','$mo','$email',current_timestamp(),'1')";
				if ($con->query($sql)==true) {
					$_SESSION['user_id']="$counter";
					$_SESSION['uname']="$uname";
					$_SESSION['fname']="$fname";
					header("Location: http://localhost/project/user/home.php");
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function reportCrime($ctitle,$cdetails,$cdate,$ccity,$user_id,$complaint_status){
			require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(crime_id) from crime";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['max(crime_id)'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				
				$sql = "insert into crime values($user_id,$counter,'$ctitle','$cdetails','$ccity','$cdate',$complaint_status,'p',1,current_timestamp())";
				echo "<script>alert($sql);</script>";
				if ($con->query($sql)==true) {
					$_SESSION['crime_id']="$counter";
					header("Location: http://localhost/project/user/reports.php");
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function writefeedBack($user_id,$fdetails){
			require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(feedback_id) from feedback";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['max(feedback_id)'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				$sql = "insert into feedback values($user_id,$counter,'$fdetails',current_timestamp())";
				if ($con->query($sql)==true) {
					echo "<script>alert('Feedback submitted successfully..');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function response($deptid,$crimeid){
	require '../database/dblib.php';
	$sql1 = "SELECT act_details,act_details,dept_id from crime_act where crime_id=$crimeid and dept_id=$deptid";
	$result1= $con->query($sql1);
	if($result1->num_rows>0){											
		while($row=$result1->fetch_assoc()){
			
				echo "<div class=\"chip\" style='display:block;width:50%;height:auto;float:left'>".$row['act_details']."</div>";
			
		}
	}
}
function writeResponse($dept_id,$crime_id,$act_details){
	require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(act_id) from crime_act";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['max(act_id)'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				$sql = "insert into crime_act values($crime_id,$dept_id,$counter,'$act_details',current_timestamp())";
				if ($con->query($sql)==true) {
					echo "<script>alert('response posted successfully');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}

function comments($user_id,$crimeid,$suser_id){
	require '../database/dblib.php';
	$sql1 = "SELECT comment_details,user_id from comment where crime_id=".$crimeid."";
	$flag=0;
	$result1= $con->query($sql1);
	if($result1->num_rows>0){											
		while($row=$result1->fetch_assoc()){
			if($row['user_id']==$suser_id){
				echo "<div class=\"chip\" style='display:block;width:50%;float:right'>".$row['comment_details']."</div>";
			}
			else{
				echo "<div class=\"chip\" style='display:block;width:50%;float:left'>".$row['comment_details']."</div>";
			}
		}
	}
}
function writeComment($user_id,$crime_id,$comment_details){
	require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(comment_id) from comment";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['max(comment_id)'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				$sql = "insert into comment values($user_id,$crime_id,$counter,'$comment_details',current_timestamp())";
				if ($con->query($sql)==true) {
					echo "<script>alert('comment posted successfully');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function file_complaint($crime_id){
	require '../database/dblib.php';
			
			$sql = "update crime set complaint_status=0 where crime_id=$crime_id";
			
				if ($con->query($sql)==true) {
					echo "<script>alert('Complaint filed successfully');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function verify($crime_id){
	require '../database/dblib.php';
			
			$sql = "update crime set crime_status='v' where crime_id=$crime_id";
			
				if ($con->query($sql)==true) {
					echo "<script>alert('Crime verified successfully');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function reject($crime_id){
	require '../database/dblib.php';
			
			$sql = "update crime set crime_status='f' where crime_id=$crime_id";
			
				if ($con->query($sql)==true) {
					echo "<script>alert('Crime Rejected successfully');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}
function counter($field,$table,$where_field,$where_name){
	require '../database/dblib.php';
							$sql_count="select count($field) from $table where $where_field=$where_name ";
							
							$result= $con->query($sql_count);
								if($result->num_rows>0)
								{
									$row=$result->fetch_assoc();
									echo $row['count('.$field.')'];
								}
							
}
function counter_str($field,$table,$where_field,$where_name){
	require '../database/dblib.php';
							$sql_count="select count($field) from $table where $where_field='$where_name' ";
							
							$result= $con->query($sql_count);
								if($result->num_rows>0)
								{
									$row=$result->fetch_assoc();
									echo $row['count('.$field.')'];
								}
							
}

function deleteCrime($crimeid){
	require '../database/dblib.php';
						
						$sql = "update crime set isdel=0 where crime_id=$crimeid";
						if ($con->query($sql)==true) {
							
							
						}
						else {	
							echo $con->error ;
						}
					}
function deleteUser($userid){
	require '../database/dblib.php';
					
						$sql = "update user set isdel=0 where user_id=$userid";
						if ($con->query($sql)==true) {
							
							
						}
						else {	
							echo $con->error ;
						}
					}
function test_input($data){
	$data=trim($data);
	$data=stripslashes($data);
	$data=htmlspecialchars($data);
	return $data;
}
function email_val($data){
	$data = filter_var($data, FILTER_SANITIZE_EMAIL);
	if (!filter_var($data, FILTER_VALIDATE_EMAIL) === false) {
		return true;
} else {
		return false;
}
}
function int_val($data){
if (filter_var($data, FILTER_VALIDATE_INT) === 0 || !filter_var($data, FILTER_VALIDATE_INT) === false) {
   return true;
} else {
  return false;
}	
}
?>
<script src="modalcl.js"></script>