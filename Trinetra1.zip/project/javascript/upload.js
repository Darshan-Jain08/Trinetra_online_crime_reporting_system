var selectedFiles= [];

updateList = function() {
	
  var input = document.getElementById('file');
  var output = document.getElementById('fileList');
	output.innerHTML="";
	output.style.backgroundColor="white";
  for (var i = 0; i < input.files.length; ++i) {
	var filename= input.files.item(i).name;
    output.innerHTML += '<div class=\"chip\">'+'<span class=\"cl\">'+filename +'</span>'+'</div>';
	selectedFiles.push(filename);
  }
}

function removeFile(e,filename){
	e.parentElement.remove();	
	var index = selectedFiles.indexOf(filename);
	if (index !== -1) {
		selectedFiles.splice(index, 1);
	}
}
function myFunction() {
  var checkBox = document.getElementById("checkbox");
  
  if (checkBox.checked == true){
	return true;
  } else {
    return false;
  }
}