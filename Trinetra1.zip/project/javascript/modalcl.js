function cl(var1){
var ele = document.getElementById(var1);
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == ele) {
        ele.style.display = "none";
    }
}