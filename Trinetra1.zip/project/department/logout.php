<?php
	session_start();
	unset($_SESSION['dname']);
	if(!isset($_SESSION['dname'])){
		header("location:index.php");
	}
?>