<?php
function loginDiv($uname,$password){
	echo "<div class='modal1' id='loginr'>
					<form class='modal-content ' action=". $_SERVER['PHP_SELF']." method='post'>
						<div class='imgcontainer'>
							<span onclick=\"document.getElementById('loginr').style.display='none'\" class='close' title='Close Modal'>&times;</span>
						</div>
							<h2 align='center'>Login</h2>
								<h4 align='center' style='color:red;'>Invalid department name or password!!!</h4>
						<div class='container'>
							 <input type='text' name='dname' id='dname' placeholder='Department Name' onfocusout='capital()' required autocomplete='off'  value=\"$uname\" >
						  <input type='password' name='password' id='password' placeholder='password'required value=\"$password\">
							<button name='btnlogin'>Login</button>
							<label>
								<input type='checkbox' id='show' onclick=\"showPassword()\">Show password
							</label>
						</div>
						<div class='container' style='background-color:#f1f1f1'>
							<span class='psw'> <a onclick=\"document.getElementById('frgtpsw').style.display='block'\" style='width:auto;'>Forgot password?</a></span>
							<span class='sgn'>Don't have an account? <a onclick=\"document.getElementById('signup').style.display='block'\" style='width:auto;'>Signup</a></span>
						</div>
					</form>
					</div>";
}
function signupDiv($dname,$password,$address,$email,$msg){
	echo "<div id='signupv' class='modal1'>
					  <form class='modal-content' action=".$_SERVER['PHP_SELF']." method='post' style='margin:auto'>
						<div class='imgcontainer'>
						   <span onclick=\"document.getElementById('signupv').style.display='none'\" class='rarr' >&larr;</span>
						</div>
						<h2 align='center'>Signup</h2>
						<h4 align='center' style='color:red;'>$msg</h4>
						<div class='container'>
						   <select class='dropdown' name='city'>
							<option>Ahmedabad</option>
							<option>Surat</option>	
							<option>Vadodara</option>	
							<option>Rajkot</option>
							<option>Bhavnagar</option>	
							<option>Jamnagar</option>	
							<option>Gandhinagar</option>
							<option>Junagadh</option>	
							<option>Gandhidham</option>
							<option>Anand</option>	
							<option>Navsari</option>	
							<option>Morbi</option>	
							<option>Nadiad</option>	
							<option>Surendranagar</option>		
							<option>Bharuch</option>	
							<option>Mehsana</option>	
							<option>Bhuj</option>
							<option>Porbandar</option>	
							<option>Palanpur</option>
							<option>Valsad</option>		
							<option>Vapi</option>	
							<option>Gondal</option>		
							<option>Veraval</option>	
							<option>Godhra</option>		
							<option>Patan</option>	
							<option>Kalol</option>	
							<option>Dahod</option>	
							<option>Botad</option>	
							<option>Amreli</option>	
							<option>Deesa</option>		
							<option>Jetpur</option>	
						 </select>
					  
			
						  <input type='password' name='password' id='password' placeholder='password'required value=\"$password\">
						  <input type='text' name='email' placeholder='Department Email' required autocomplete='off' value=\"$email\">
						  <input type='text' name='address' id='address' placeholder='Department Address' required autocomplete='off' value=\"$address\">
						  
						  <button name='btnsignup'>signup</button>
						</div>
						<div class='container' style='background-color:#f1f1f1'>
						  <button type='button' onclick=\"document.getElementById('signupv').style.display='none'\" class='cancelbtn'>Cancel</button>
						</div>
					  </form>
					</div>";
}

function forgotPsw($uname,$moe,$msg){
	echo "<div id='frgpsw' class='modal1' >
					<form class='modal-content ' action=". $_SERVER['PHP_SELF']." method='post'>
						<div class='imgcontainer'>
							<span onclick=\"document.getElementById('frgpsw').style.display='none'\" class='close' title='Close Modal'>&times;</span>
						</div>
							<h2 align='center'>Forgot password</h2>
							<h4 align='center' style='color:red;'>$msg</h4>
						<div class='container'>
							<input type='text' name='dname' id='dname' placeholder='Enter department' onfocusout='capital()' required autocomplete='off'  value=\"$uname\" >
							<input type='text' name='email' placeholder='Department Email' required autocomplete='off' value=\"$moe\">
							<button name='btnfrgpsw'>Verify</button>	
						</div>
						<div class='container' style='background-color:#f1f1f1'>
						  <button type='button' onclick=\"document.getElementById('frgpsw').style.display='none'\" class='cancelbtn'>Cancel</button>
						</div>
					</form>
					</div>";
}
function forgotPswConf($uname,$moe,$msg){
	echo "<div id='frgpswco' class='modal1' >
					<form class='modal-content' action=". $_SERVER['PHP_SELF']." method='post'>
						<div class='imgcontainer'>
							<span onclick=\"document.getElementById('frgpswco').style.display='none'\" class='close' title='Close Modal'>&times;</span>
						</div>
							<h2 align='center'>Forgot password</h2>
							<h4 align='center' style='color:green;'>$msg</h4>
						<div class='container'>
							<input type='text' name='dname' id='dname' placeholder='Enter department' onfocusout='capital()' required autocomplete='off'  value=\"$uname\" >
							<input type='text' name='email' placeholder='Department Email' required autocomplete='off' value=\"$moe\">
							<input type='password' name='password' id='password' placeholder='Enter New password'required >
							
							<button name='btnfrgpswConf'>Change password</button>	
						</div>
						<div class='container' style='background-color:#f1f1f1'>
						  <button type='button' onclick=\"document.getElementById('frgpswco').style.display='none'\" class='cancelbtn'>Cancel</button>
						</div>
					</form>
					</div>";
}
function signup($dname,$password,$address,$email){
			require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(dept_id) as d from dept";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['d'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				$sql = "insert into dept values($counter,'$dname','$password','$address','$email',current_timestamp())";
				if ($con->query($sql)==true) {
					$_SESSION['dept_id']="$counter";
					$_SESSION['dname']="$dname";
					
					header("Location: http://localhost/project/department/reports.php");
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}

function feedBack($user_id,$fdetails){
			require '../database/dblib.php';
			//auto increment code
			$sql = "SELECT max(feedback_id) from feedback";
			$result= $con->query($sql);
			if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc()){
						$counter=$row['max(feedback_id)'] ;
					}
					$counter++;	
				}
				else{
					$counter=1;
				}
				//data insert code 
				$sql = "insert into feedback values($user_id,$counter,'$fdetails',current_timestamp())";
				if ($con->query($sql)==true) {
					echo "<script>alert('Feedback submitted successfully..');</script>";
				}
				else {
					echo "Error inserting data: " . $con->error;
				}
}

function test_input($data){
	$data=trim($data);
	$data=stripslashes($data);
	$data=htmlspecialchars($data);
	return $data;
}
function email_val($data){
	$data = filter_var($data, FILTER_SANITIZE_EMAIL);
	if (!filter_var($data, FILTER_VALIDATE_EMAIL) === false) {
		return true;
} else {
		return false;
}
}
function int_val($data){
if (filter_var($data, FILTER_VALIDATE_INT) === 0 || !filter_var($data, FILTER_VALIDATE_INT) === false) {
   return true;
} else {
  return false;
}	
}
?>
<script src="modalcl.js"></script>