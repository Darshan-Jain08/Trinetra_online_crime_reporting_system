<?php
	require '../database/database.php';
	require 'lib.php';
	if(isset($_SESSION['dname'])){
		header("Location: http://localhost/project/department/home.php");
	}
?>
<html>
<head>
<title>Trinetra Department-Login</title>
<link rel = "icon" href="./images/logo_final.png" type = "image/x-icon" style="border-radius:10px">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="../css/index.css">
</head>
<body>
<?php
if(isset($_POST['btnsignup'])){
	$dname=test_input($_POST['city']);
	$password=test_input($_POST['password']);
	$address=$_POST["address"];
	$email=test_input($_POST['email']);
		if(empty($dname) || empty($password)  || empty($address) || empty($email)){
				$msg="all fields must be filled!!";
				signupDiv($dname,$password,$address,$email,$msg);
		}
		else{
				$sql = "SELECT dname from dept where dname='$dname'";
				$result= $con->query($sql);
				if($result->num_rows>0)
				{
						
							$msg="Department already exists. please try another one!!";
							signupDiv($dname,$password,$address,$email,$msg);
							
				}
				else{
					    if(email_val($email)===true){
									
									signup($dname,$password,$address,$email);
								}
								else {
									$msg="Please enter valid email address!";
									signupDiv($dname,$password,$address,$email,$msg);
								}
						
				}					
			}						
	}

if (isset($_POST['btnlogin'])) {
	
			$dname=test_input($_POST['dname']);
			$dpassword=test_input($_POST['password']);
			$sql = "SELECT dept_id,dname,dpassword from dept where dname='$dname' and dpassword='$dpassword'";
			$result= $con->query($sql);
		if($result->num_rows>0)
		{
			while($row=$result->fetch_assoc()){
				if($row['dname']=== $dname && $row['dpassword']=== $dpassword){					
					$_SESSION['dname']=$dname;
					$_SESSION['dept_id']=$row['dept_id'];
					header("Location: reports.php");
				}
				else{
					loginDiv($dname,$dpassword);
				}
			}
		}
		else{
				loginDiv($dname,$dpassword);
			}
				
}
if(isset($_POST['btnfrgpsw'])){
			$dname=test_input($_POST['dname']);
			$moe=test_input($_POST['email']);
			$sql = "SELECT dname,email from dept where dname='$dname'";
			$result= $con->query($sql);
		if($result->num_rows>0)
		{
			while($row=$result->fetch_assoc()){
				if($row['dname']== $dname){					
					 if($row['email']===$moe){
						$msg="Vefication successful.";
						forgotPswConf($dname,$moe,$msg);
					}
					else{
						  $msg= "mobile email dosen't match"; 
						  forgotPsw($dname,$moe,$msg);
					}
				}
				else{
					 $msg= "Invalid department name.please try again";
					forgotPsw($dname,$moe,$msg);					 
				}
			}
		}
		else{
				 $msg= "Invalid department name.please try again";
					forgotPsw($dname,$moe,$msg);
			}
				$con->close();
}
if(isset($_POST['btnfrgpswConf'])){
			$dname=test_input($_POST['dname']);
			$password=test_input($_POST['password']);
		
			$sql = "update dept set dpassword='$password' where dname='$dname'";
		if ($con->query($sql)==true) 
		{
			echo "<script>alert('Password was updated successfully');</script>";
			
		}
		else{
				 $msg= "Error updating password";
				forgotPswConf($uname,$moe,$msg);
			}
		$con->close();
}

?>
<div class="show"> 
<h2>Welcome Department</h2>
<button onclick="document.getElementById('login').style.display='block'" style="width:auto;font-size:20px;color:black">Get started</button>
</div>

<!--login form-->
<div id="login" class="modal">
  <form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('login').style.display='none'" class="close" title="Close Modal">&times;</span>
      <!--<img src="img_avatar2.png" alt="Avatar" class="avatar">-->
    </div>
	<h2 align="center">login</h2>
    <div class="container"> 
	  <input type="text" placeholder="Enter Department Name" name="dname" id="dname" onfocusout="capital()" required autocomplete="off" >
	  <input type="password" placeholder="Enter Password" name="password" id="password" required >
      <button name="btnlogin">Login</button>
	 <label>
		<input type='checkbox' id='show' onclick="showPassword()">Show password
	</label>
    </div>
    <div class="container" style="background-color:#f1f1f1">
    <!--  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>-->
    <span class="psw"> <a onclick="document.getElementById('frgtpsw').style.display='block'" style="width:auto;">Forgot password?</a></span>
        <span class="sgn">Don't have an account? <a onclick="document.getElementById('signup').style.display='block'" style="width:auto;">Signup</a></span>

	</div>
  </form>
</div>

<!-- Signup form-->
<div id="signup" class="modal" name="signup">
  <form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" style="margin:auto">
    <div class="imgcontainer">
       <span onclick="document.getElementById('signup').style.display='none'" class="rarr" >&larr;</span>
       <!--<img src="img_avatar2.png" alt="Avatar" class="avatar">-->
    </div>
	<h2 align="center">Signup</h2>
    <div class="container">
	
	  <select class="dropdown" name="city">
				<option>Ahmedabad</option>
				<option>Surat</option>	
				<option>Vadodara</option>	
				<option>Rajkot</option>
				<option>Bhavnagar</option>	
				<option>Jamnagar</option>	
				<option>Gandhinagar</option>
				<option>Junagadh</option>	
				<option>Gandhidham</option>
				<option>Anand</option>	
				<option>Navsari</option>	
				<option>Morbi</option>	
				<option>Nadiad</option>	
				<option>Surendranagar</option>		
				<option>Bharuch</option>	
				<option>Mehsana</option>	
				<option>Bhuj</option>
				<option>Porbandar</option>	
				<option>Palanpur</option>
				<option>Valsad</option>		
				<option>Vapi</option>	
				<option>Gondal</option>		
				<option>Veraval</option>	
				<option>Godhra</option>		
				<option>Patan</option>	
				<option>Kalol</option>	
				<option>Dahod</option>	
				<option>Botad</option>	
				<option>Amreli</option>	
				<option>Deesa</option>		
				<option>Jetpur</option>	
			 </select>
		  
			<input type="password" name="password" id="password" placeholder="password" autocomplete='off' required>
	  <input type="text" name="email" placeholder="Department Email" autocomplete='off' required><br>
	  <input type="text" name="address" id="address" placeholder="Department Address" autocomplete='off' required>
      <button name="btnsignup">signup</button>
    </div>
    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('signup').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
  </form>
</div>
<!--forgot password form-->
<div id="frgtpsw" class="modal">
  <form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
    <div class="imgcontainer">
	  <span onclick="document.getElementById('frgtpsw').style.display='none'" class="rarr" >&larr;</span>
	  <!--<img src="img_avatar2.png" alt="Avatar" class="avatar">-->
    </div>
	<h2 align="center"> Forgot password</h2>
    <div class="container">
      <input type='text' name='dname' id='dname' placeholder='Enter department' onfocusout='capital()' required autocomplete='off'   > 
	   <input type="text" placeholder="Department Email" name="email" autocomplete='off' required>
      <button name="btnfrgpsw">Verify</button>
    </div>
    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('frgtpsw').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
  </form>
</div>
<script src="modalcl.js"></script>
<script>
function showPassword() {
	
	var check=document.getElementById('show');
			  if (check.checked) {
					document.getElementById('password').type="text";
			  } else {
					document.getElementById('password').type="password";
			  }
			}
function capital(){
let text = document.getElementById('dname').value;
let letter =text.charAt(0).toUpperCase() + text.slice(1);
document.getElementById("dname").value = letter;
}
</script>
</body>
</html>