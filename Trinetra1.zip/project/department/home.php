<?php
require '../library/pageFunction.php';
require 'master.php';
$sdname=$_SESSION['dname'];
$sdept_id=$_SESSION['dept_id'];
?>
<head>
<link rel="stylesheet"  href="../css/dots.css">
<style>
.row h3{
	color:brown;
}
</style>
</head>

<div class="rightcolumn">
			<section id="reports" >
					<div class="card">
					<?php
					
					if(isset($_POST['response'])){
						$crimeid=$_POST['crimeid'];
						$content=$_POST['content'];
						writeResponse($sdept_id,$crimeid,$content);
					}
					$sql_count="select count(crime_id) from crime where crime_location='$sdname' and isdel=1 and complaint_status=0 and crime_status='v'";
							$result= $con->query($sql_count);
								if($result->num_rows>0)
								{
									$row=$result->fetch_assoc();
									$no_of_crime= $row['count(crime_id)'];
								}
	?>
						<p>Reported Crimes in :<?php echo "<span style='font-weight:bold;'>$sdname</span>";?></p>
						<?php echo "Records found:".$no_of_crime;?>
						</div>
						<div style="height:auto;border-top:3px solid grey;padding:5px;">
						 <?php
						  
								$sql = "SELECT * from crime where crime_location='$sdname' and isdel=1 and crime_status='v' and complaint_status=0";
								$result= $con->query($sql);
								if($result->num_rows>0)
								{
									
								while($row=$result->fetch_assoc()){
										$user_id=$row['user_id'];
										$sql1="select uname from user where user_id=$user_id";
										$result1=$con->query($sql1);
										if($result1->num_rows>0)
										{
											$row1=$result1->fetch_assoc();
											$uname=$row1['uname'];
										}
										$crimeid=$row['crime_id'];
										$dwld="dwld".$row['crime_id'];
										$crime="crime".$row['crime_id'];
										$resp="resp".$row['crime_id'];
										?><table class='report' onclick="document.getElementById('<?php echo $crime;?>').style.display='block';">
										<tr>
										<td style='width:40%'><?php echo $row['crime_title']; ?></td>
										<td style='margin-top:10px;float:right'>
										<div class="chip" style="width:35px;height:45px;background-color:transparent">
											<a onclick="document.getElementById('<?php echo $crime;?>').style.display='block';" ><img src="../images/icons/expand.png" alt="Person" style="width:35px;height:35px;margin-top:3px;"></a>
										</div>
										</td>
										</tr>
										</table>
										<?php
										$odate= $row["crime_date"];
										$newDate = date("d-m-Y", strtotime($odate));
										?>
										<div id='<?php echo $crime ?>' class='modal'> 
											<form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"method="post"  enctype="multipart/form-data" style="margin:auto;height:auto;width:70%">
												
												   <span onclick="document.getElementById('<?php echo $crime ?>').style.display='none'" class="rarr" style="position:relative;">&larr;</span>
												
												<div style="padding:10px;">
													<fieldset>
													<legend><h2 align="center"><?php echo $row['crime_title']?></h2></legend>
													<div class="container">
													<div class="row">
													<div style="width:49%;float:left;">
													
													  <h3>User name</h3>
													  <span><?php echo $uname?></span>
													  <h3>Crime Details</h3>
														<span><?php echo $row['crime_details']?></span>
														<h3>Crime Location</h3>
														<p><?php echo $row['crime_location']?></p>
													</div>												
													<div style="width:49%;float:left;margin-left:2%;">
														<h3 >Crime Date</h3>
														<p><?php echo $newDate?></p>
														<h3 >Reporing Date</h3>
														<p><?php echo $row['posting_date']?></p>
														<h4><p style="color:green;">Complaint Filed</p></h4>
														<h4 align="right">
																		<div class="chip" style="background-color:white">
																		<img src="../images/icons/verified.png" alt="Person"  style="cursor:pointer">
																		<span style="color:green">Verified</span>
																		</div>
														</h4>	
													</div>
													<hr/>
														<div class="chip" style="width:20px">
														<img src="../images/icons/response.png" alt="Person" onclick="document.getElementById('<?php echo $resp;?>').style.display='block';" style="cursor:pointer">
														</div>
														<div class="chip" style="width:20px">
														<img src="../images/icons/download.png" alt="Person" onclick="document.getElementById('<?php echo $dwld;?>').style.display='block';" style="cursor:pointer">
														</div>
													</div>
													<br>
													</div>  
													</fieldset>	
												</div>												
										  </form>
										</div>
										
										
										<div id='<?php echo $resp ?>' class='modal'>
											  <form class='modal-content animate' action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method='post' style='margin:auto;height:350px;margin-top:10%;'>
												<div class='imgcontainer'>
												   <span onclick="document.getElementById('<?php echo $resp;?>').style.display='none';" class='rarr' >&larr;</span>
												</div>
												<h2 align='center'>Response</h2>
												<div class='container' style="height:150px;overflow-x:scroll; overflow-x: hidden;">
													<?php
													 response($sdept_id,$crimeid);
													?>		
													
												</div>
												<input type="text" name="content" placeholder="Write Response" >
													<button  name="response">post</button>
													<input type='hidden' name='crimeid' value="<?php echo $crimeid?>" hidden >
											  </form>
										</div>
										<div id='<?php echo $dwld ?>' class='modal'>
											  <form class='modal-content animate' action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method='post' style='margin:auto;height:350px;margin-top:10%;'>
												<div class='imgcontainer'>
												   <span onclick="document.getElementById('<?php echo $dwld;?>').style.display='none';" class='rarr' >&larr;</span>
												</div>
												<h2 align='center'>Download Proof</h2>
												<?php
												$id="CR".$crimeid;
												$dir_path = "../upload/exp/$id/";
												$options="";
												if(is_dir($dir_path))
												{
													$files = opendir($dir_path);
													
														if($files)
														{
															  while(($file_name = readdir($files)) !== FALSE)
															  {
																  if($file_name != '.' && $file_name != '..')
																	  {
																		  ?><div class="chip"><?php
																		   echo $file_name;
																		   ?>
																		   <a href="<?php echo $dir_path.$file_name?>" download>
																		   <img src="../images/icons/download.png" alt="Person" style="width:35px;height:35px;margin-top:3px;">
																		   </a></div>
																		   <?php
																	  }
															  }
														}		
												}
												?>
												
											  </form>
										</div>
										<?php
									}
								}
								else{
									$err= "now record found!!";
								}
								?>
						</div>
		</section>
</div>
<script>

</script>


