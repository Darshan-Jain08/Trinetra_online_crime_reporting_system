<?php
	include 'settings.php';
?>
<style>
.row h3{
	color:brown;
}
</style>
<div class="leftcolumn_set">
				<h2 align="center">Settings</h2>
						<div class="header" style="width:16%;height:85%;margin-top:5px" id="leftpanel">
						<table cellpadding=7>
							<tr class="slab" style="background-color:rgba(0, 185, 255, 0.1)" onclick="forward_Info()">
								<td>
								<div class="chipsl">
								<a href="settings_dept.php" style="padding-left:5px;padding-top:5px;position:absolute"><img src="../images/icons/user_settings.png" alt="Person"></a>
								</div>
								</td>
								<td style="padding-bottom:15px">
								Department Info
								</td>
							</tr>
							<tr class="slab" onclick="forward_logout()"> 
								<td>
								<div class="chipsl">
									<a href="logout.php" style="padding-left:5px;padding-top:5px;position:absolute"><img src="../images/icons/logout.png" alt="Person"></a>
								</div>
								</td>
								<td style="padding-bottom:15px">
								Logout
								</td>
							</tr>
							<tr class="slab" onclick="forward_home()"> 
								<td>
								<div class="chipsl">
									<a href="home.php" style="padding-left:5px;padding-top:5px;position:absolute"><img src="../images/icons/home.png" alt="Person"></a>
								</div>
								</td>
								<td style="padding-bottom:15px">
								Home
								</td>
							</tr>
							
						</table>
						
						</div>
			  </div>
<div class="rightcolumn_set" >	
		
		<h2 align="center">Department information</h2>
		<div class="card">
		
		<div class="container">
							<div class="row">
						<?php
							$dname=$_SESSION['dname'];
									$sql="select * from dept where dname='$dname' ";
									$result=$con->query($sql);
									if($result->num_rows>0)
									{
										$row=$result->fetch_assoc();
										$dname=$row['dname'];
										$daddress=$row['daddress'];
										$email=$row['email'];
										$ds_date=$row['ds_date'];
									}
						
								?>
							<div style="width:49%;float:left;">
							<form  action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
							  <h3>Department Name: </h3><?php echo $dname;?><br>
							  <h3>Address: </h3><?php echo $daddress;?><br>
							  <h3>Email:</h3><?php echo $email;?><br>
							</div>
							<div style="width:49%;float:left;margin-left:2%;">
								 <h3>Joining Date:</h3> <?php echo $ds_date;?>
							</div>
							</div><br>
							
							</form>  
		
		</div><br>
		  
		  
		</div>
	   
	  
		
		</div>
		
	</div>

	<script>
	function myFunction(var1) {
	document.getElementById(var1).disabled = false;
	document.getElementById(var1).focus();
}
function myFunctionlost(var1){
	document.getElementById(var1).disabled = true;
}
	</script>