<?php
require '../library/pageFunction.php';
require 'master.php';

?>
<div class="rightcolumn">
			<section id="reports">
					<div class="card">
						<h3>Notifications</h3>
						 <?php
						 $suser_id=$_SESSION['user_id'];
								$sql = "SELECT * from crime where user_id=$suser_id";
								$result= $con->query($sql);
								if($result->num_rows>0)
								{

								while($row=$result->fetch_assoc()){
										echo"<table class='report'>";
										echo"<tr>";
										$crimeid=$row['crime_id'];
										$divid="signup".$row['crime_id'];
										echo "<td>".$crimeid."</td>";
										echo "<td style='width:40%'>" .$row['crime_details']."</td>";?>
										<td style='width:40%;margin-top:10px;'>
										<div class="chip" >
											<a onclick="document.getElementById('<?php echo $divid;?>').style.display='block';"  style="padding:5px;padding-top:5px;position:absolute"><img src="../images/c.png" alt="Person"></a>
										</div>
										<div class="chip" >
											<a onclick="document.getElementById('<?php echo $divid;?>').style.display='block';" ><img src="../images/expand.png" alt="Person"></a>
										</div>
										</td><?php
										echo "</tr>";
										echo"</table>";
										$odate= $row["crime_date"];
										$newDate = date("d-m-Y", strtotime($odate));
										?>
										<div id='<?php echo $divid ?>' class='modal'>
											  <form class='modal-content animate' action='action.php' method='post' style='margin:auto'>
												<div class='imgcontainer'>
												   <span onclick="document.getElementById('<?php echo $divid;?>').style.display='none';" class='rarr' >&larr;</span>
												</div>
												<h2 align='center'><?php echo $crimeid?></h2>
												<div class='container'>
													<?php
													comments($row['user_id'],$crimeid,$suser_id);
													?>		
													<input type="text" name="crime_title" placeholder="Write something" >
													<button  onclick="document.getElementById('<?php echo $divid;?>').style.display='block';">post</button>
												</div>
											  </form>
											 </div>
										<?php
									}
								}
								else{
									$err= "now record found!!";
								}
								?>
						</div>
		</section>
</div>

