
<?php
	require '../database/database.php';
	require '../library/lib.php';
	if(!isset($_SESSION['dname'])){
		header("Location: http://localhost/project/department/index.php");
	}
	
?><html>
	<head>
		<title>Trinetra</title>
		<link rel = "icon" href="./images/logo.png" type = "image/x-icon" style="border-radius:10px">
		<link rel="stylesheet"  href="../css/home.css">
		<link rel="stylesheet" href="../css/index.css">
		<link rel="stylesheet" href="../css/settings.css">
		
		<link rel="stylesheet"  href="../css/uploadchip.css">
		<link rel = "icon" href="../images/header.png"type = "image/x-icon">
	</head>
<body>
	
	
		
			<div class="leftcolumn_set">
						
						</div>
			  </div>
			  
				<div class="rightcolumn_set">	
					
				</div>
			  
			</body>
<script>
	function Previous() {
            window.history.back()
        }
	function forward_Info(){
		window.location='http://localhost/project/department/settings_dept.php';
	}
	function forward_feedback(){
		window.location='http://localhost/project/department/settings_feedback.php';
	}
	function forward_dept(){
		window.location='http://localhost/project/department/settings_department.php';
	}
	function forward_logout(){
		window.location='http://localhost/project/department/logout.php';
	}
	function forward_home(){
		window.location='http://localhost/project/department/home.php';
	}
	function forward_logout(){
            var doc;
            var result = confirm("Do you really want to logout!");
            if (result == true) {
                window.location='http://localhost/project/department/logout.php';
            } else {
              
            }  
	}
			</script>
	</html>