<html>
<head>
<title>Trinetra </title>
<link rel = "icon" href="./images/logo_final.png" type = "image/x-icon" style="border-radius:10px">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="css/index.css">
<style>
a{
	text-decoration:none;
	background-color:linen;
	padding:10px;
	border-radius:25px;
}
</style>
</head>
<body>
<div class="show"> 
<h2>Welcome To Trinetra</h2>
<a href="http://localhost/project/user/home.php" style="width:auto;font-size:20px;color:black" target="_blank">User-login</a><br><br>
<a href="http://localhost/project/department/home.php" style="width:auto;font-size:20px;color:black" target="_blank">Department-login</a><br><br>
<a href="http://localhost/project/admin/home.php" style="width:auto;font-size:20px;color:black" target="_blank">Headquarters-login</a><br><br>
</div>

