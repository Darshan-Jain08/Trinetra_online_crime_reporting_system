<?php
	session_start();
?>
<?php 
	$con = new mysqli("localhost", "root","","trinetra");
	if ($con->connect_error) {
	die("Connection failed... please check your database connection");
	}
	
?>