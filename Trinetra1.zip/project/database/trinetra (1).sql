-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2024 at 07:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trinetra`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `user_id` int(5) NOT NULL,
  `crime_id` int(5) NOT NULL,
  `comment_id` int(5) NOT NULL,
  `comment_details` varchar(20) NOT NULL,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`user_id`, `crime_id`, `comment_id`, `comment_details`, `comment_date`) VALUES
(1, 1, 1, 'what was happen abou', '2024-09-06'),
(1, 1, 2, 'What will be the sta', '2024-09-06');

-- --------------------------------------------------------

--
-- Table structure for table `crime`
--

CREATE TABLE `crime` (
  `user_id` int(5) NOT NULL,
  `crime_id` int(5) NOT NULL,
  `crime_title` varchar(200) NOT NULL,
  `crime_details` varchar(500) NOT NULL,
  `crime_location` varchar(25) NOT NULL,
  `crime_date` date NOT NULL,
  `complaint_status` tinyint(1) NOT NULL,
  `crime_status` char(1) NOT NULL,
  `isdel` tinyint(1) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crime`
--

INSERT INTO `crime` (`user_id`, `crime_id`, `crime_title`, `crime_details`, `crime_location`, `crime_date`, `complaint_status`, `crime_status`, `isdel`, `posting_date`) VALUES
(1, 1, 'Car Stolen', 'A car was stolen from a public parking lot in downtown varodara. The vehicle was a red 2018 Toyota Corolla.', 'Vadodara', '2024-09-06', 1, 'v', 1, '2024-09-06 04:56:52'),
(2, 2, 'kidnapping in Maple Avenue', 'A 10-year-old child was abducted from a playground at Maple Avenue. Witnesses report seeing a white van speeding away from the scene.', 'Ahmedabad', '2024-09-06', 1, 'v', 1, '2024-09-06 05:15:07'),
(3, 3, 'Murder on Riverside Street', 'A 35-year-old male was found dead at his home on Riverside Street. Neighbors reported hearing a loud argument followed by a gunshot.', 'Vadodara', '2024-09-06', 1, 'p', 1, '2024-09-06 05:17:59');

-- --------------------------------------------------------

--
-- Table structure for table `crime_act`
--

CREATE TABLE `crime_act` (
  `crime_id` int(5) NOT NULL,
  `dept_id` int(5) NOT NULL,
  `act_id` int(5) NOT NULL,
  `act_details` varchar(100) NOT NULL,
  `act_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `dept_id` int(5) NOT NULL,
  `dname` varchar(25) NOT NULL,
  `dpassword` varchar(30) NOT NULL,
  `daddress` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `ds_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`dept_id`, `dname`, `dpassword`, `daddress`, `email`, `ds_date`) VALUES
(1, 'Vadodara', 'vad123', 'Channi Varodara', 'channipolice@gmail.com', '2024-09-06 05:31:07'),
(2, 'Ahmedabad', 'AMD123', 'Ahmedabad Gita Mindir', 'AhmedabadPolice@gmail.com', '2024-09-06 05:36:37');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `user_id` int(5) NOT NULL,
  `feedback_id` int(5) NOT NULL,
  `feedback_details` varchar(50) NOT NULL,
  `feedback_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`user_id`, `feedback_id`, `feedback_details`, `feedback_date`) VALUES
(1, 1, 'Still in Progress', '2024-09-06 05:25:46');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `media_id` int(5) NOT NULL,
  `crime_id` int(5) NOT NULL,
  `media_type` varchar(8) NOT NULL,
  `media_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`media_id`, `crime_id`, `media_type`, `media_name`) VALUES
(1, 1, 'image/we', 'media1.webp'),
(2, 2, 'image/jp', 'media1.jpg'),
(3, 3, 'image/we', 'media1.webp');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(5) NOT NULL,
  `uname` varchar(25) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile_no` varchar(10) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `sdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `isdel` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `uname`, `fname`, `password`, `mobile_no`, `email`, `sdate`, `isdel`) VALUES
(1, 'Pradip Yadav', 'pradip123', 'pradip@123', '9876543012', 'pradip4145@gmail.com', '2024-09-06 04:50:58', 1),
(2, 'Gayatri Solanki', 'gayu123', 'gayatri123', '', 'gayatri.solanki.8000@gmail.com', '2024-09-06 05:02:49', 1),
(3, 'Darshan Jain', 'Darshan123', 'darshan@123', '', 'darshanjain46558@gmail.com', '2024-09-06 05:16:45', 1),
(4, 'Ayushi Paghadar', 'ayushi111', 'ayushi@123', '', 'paghadarayushi@gmail.com', '2024-09-06 05:21:34', 1),
(5, 'Rohan Patel', 'Rohan123', 'Rohan@123', '', 'Rohan123@gmail.com', '2024-09-06 05:48:34', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `crime_id` (`crime_id`);

--
-- Indexes for table `crime`
--
ALTER TABLE `crime`
  ADD PRIMARY KEY (`crime_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `crime_act`
--
ALTER TABLE `crime_act`
  ADD PRIMARY KEY (`act_id`),
  ADD KEY `crime_id` (`crime_id`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`crime_id`) REFERENCES `crime` (`crime_id`);

--
-- Constraints for table `crime`
--
ALTER TABLE `crime`
  ADD CONSTRAINT `crime_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `crime_act`
--
ALTER TABLE `crime_act`
  ADD CONSTRAINT `crime_act_ibfk_1` FOREIGN KEY (`crime_id`) REFERENCES `crime` (`crime_id`),
  ADD CONSTRAINT `crime_act_ibfk_2` FOREIGN KEY (`dept_id`) REFERENCES `dept` (`dept_id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
