<?php

require 'master.php';
 
?>

<head>
<link rel="stylesheet"  href="../css/dots.css">
<link rel="stylesheet"  href="../css/users.css">
</head>

<div class="rightcolumn">
<?php
			
					if(isset($_POST['delete'])){
						$userid=$_POST['userid'];
						 deleteUser($userid);
					}
						?>
<section id="reports" >
<div class="card" style="height:20%">
						<h2 style="float:left">Users</h2>
						<form action="" method="post" >
							<div  style="float:right">
								<input type="text" name="search" id="val" placeholder="search user" onkeyup="myFunction(document.getElementById('val').value)" style="width:300px">
							</div>
						</form>
						</div>
							<div class="row" id="cont" style="height:400px; padding:5%;overflow-x:scroll; overflow-x: hidden;background-color:lightgrey;border-radius:5px;">
								<?php
									$sql="select * from dept ";
									$result=$con->query($sql);
									if($result->num_rows>0){
										while($row=$result->fetch_assoc()){?>
											<table  cellpadding=10 class='users' name="" onclick="document.getElementById('<?php echo $row['dept_id'] ?>').style.display='block';">
											<tr>
											<td style='width:40%'><?php echo $row['dname']?></td>
											</tr>
											</table>
											<div id='<?php echo $row['dept_id'] ?>' class='modal' > 
											<form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"method="post"  enctype="multipart/form-data" style="height:80%;width:75%;">
												<div class="imgcontainer">
												   <span onclick="document.getElementById('<?php echo $row['dept_id'] ?>').style.display='none'" class="rarr" >&larr;</span>
												</div>
												<fieldset style="margin-top:50px;background-color:linen">
												<legend style="margin-left:10%"><h2 align="center"><?php echo $row['dname']?></h2></legend>
												<div class="container" style="height:60%;overflow-x:scroll; overflow-x: hidden;">
												<div class="row">
												<div style="width:49%;float:left;">
													<table  cellpadding=10 class='users' style="width:50%" onclick="document.getElementById('crimes').style.display='block';">
														<tr>
														<td style='width:80%'>reported Crimes</td>
														<td><?php counter_str("crime_id","crime","crime_location",$row['dname'])?></td>
														</tr>
													</table><br>
													
												</div>												
												<div style="width:49%;float:left;margin-left:2%;">
													<table  cellpadding=10 class='users' style="width:50%" onclick="document.getElementById('crimes').style.display='block';">
														<tr>
														<td style='width:80%' onclick=""><input type="hidden" name="userid" value="<?php echo $row['dept_id'];?>">
															<button name="delete"  style="padding:5px;width:100px"><img src="../images/icons/delete_icon.png" alt="Person" style="width:50px;height:50px;"> </button>	</td>
														</tr>
													</table><br>
													
												</div>
												</div>
												<br>
												
												 
												</div>  
												</fieldset>		
										  </form>
										</div>
										
											<?php
												}
													}
									else{
										echo "No users found...";
									}
								?>
							</div>
</div>									
</section>
</div>	
<script>
function myFunction(var1) {
  alert(var1);
		let filter = document.getElementById(var1).value.toUpperCase(); 
		let myTable = document.getElementById('cont');

		let table = myTable.getElementsByTagName('table');

		for(var i=0; i<tr.length; i++)
		{
			let td = table[i].getElementsByTagName('tr')[1];
			if(td)
			{
				let textvalue = td.textContent || td.innerHTML;
				if(textvalue.toUpperCase().indexOf(filter) > -1)
				{
					tr[i].style.display = "";
				}
				else
				{
					tr[i].style.display = "none";
				}
			}
		}
}
</script>