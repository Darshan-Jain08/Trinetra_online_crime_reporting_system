<?php
	require '../database/database.php';
	require '../library/lib.php';
	if(!isset($_SESSION['admin'])){
		header("Location: http://localhost/project/admin/index.php");
	}
?>
<html>
	<head>
		<title>Trinetra Admin</title>
		<link rel = "icon" href="./images/logo.png" type = "image/x-icon" style="border-radius:10px">
		<link rel="stylesheet"  href="../css/home.css">
		<link rel="stylesheet" href="../css/index.css">
		<link rel="stylesheet"  href="../css/uploadchip.css">
		<link rel = "icon" href="../images/header.png"type = "image/x-icon">
	</head>
	<body style=" background:#cccccc">
	<img src="../images/logo_final.png" class="logo_final" ></img>	
		<div class="header">
		
			<div class="menu-bar menu">
						<div class="col-md-4" style="width:20%;float:left;padding-top:5px;padding-left:50px">
							<a href="home.php"><img src="../images/text.png" style="width:150px;margin-left:120px"></img></a>
							
						</div>
						<div class="col-md-8" style="width:80%;float:right">
							
							  <div class="chip" style="margin:0;width:auto;padding:0">
							  <a onclick="document.getElementById('lines').style.display='block'"><img src="../images/icons/nav_lines.png" alt="Person" style="margin-left:10px;padding:10px"><img src="../images/icons/user_dark.png" alt="Person" style="padding:10px"></a>
							  </div>
							
	
						</div>
				</div>
			</div>	
	<div class="row">
	<div class="leftcolumn">
				<div class="header" style="width:5%;height:85%;" id="leftpanel">
						<div class="chipsl" >
							  <a href="home.php" style="padding-left:5px;padding-top:5px;position:absolute" class="tooltip"><img src="../images/icons/home.png" alt="Person"></img></a>
						</div>
						
						
						<div class="chipsl" >
							  <a href="verified_crimes.php" style="padding-left:5px;padding-top:5px;position:absolute" class="tooltip"><img id="bell" src="../images/icons/verified.png" alt="Person"></img></a>
						</div>
						<div class="chipsl" >
							  <a href="processing_crimes.php" style="padding-left:5px;padding-top:5px;position:absolute" class="tooltip"><img id="bell" src="../images/icons/progress.png" alt="Person"></img></a>
						</div>
						<div class="chipsl" >
							  <a href="failed_crimes.php" style="padding-left:5px;padding-top:5px;position:absolute" class="tooltip"><img id="bell" src="../images/icons/failed.png" alt="Person"></img></a>
						</div>
						<div class="chipsl" >
							  <a href="report.php" style="padding-left:5px;padding-top:5px;position:absolute"class="tooltip"><img src="../images/icons/report_icn.png" alt="Person"></img></a>
						</div>
				</div>
	  </div>
	<div class="rightcolumn">	
		
	</div>
	</div>
	
	<div id="lines" class="modal" style="background-color:transparent;">	
		<div class="container" style="width:15%;float:right;margin-top:50px;margin-right:30px;background-color:white;border-radius:25px">
			<table cellpadding=7>
							<tr class="slab" onclick="forward_Info()">
								<td>
								<div class="chipsl">
								<a href="settings_user.php" style="padding-left:5px;padding-top:5px;position:absolute"><img src="../images/icons/user_light.png" alt="Person"></a>
								</div>
								</td>
								<td style="padding-bottom:15px">
								Profile
								</td>
							</tr>
							<tr class="slab" onclick="forward_logout()">
								<td>
								<div class="chipsl">
								<a href="logout.php" style="padding-left:5px;padding-top:5px;position:absolute;text-decoration: none;"><img src="../images/icons/logout.png" alt="Person"></a>
								</div>
								</td>
								<td style="padding-bottom:15px">
								logout
								</td>
							</tr>
				</table>
	</div>
</div>
	<!--settings-->
		
		<!-- report-->
	

	</body>

	
	
	<script>
		var report = document.getElementById('report');
		var lines=document.getElementById('lines');
		window.onclick = function(event) {
			 if(event.target== report){
				report.style.display="none";
				}
		}
		window.onclick = function(event) {
			 if(event.target== lines){
				lines.style.display="none";
				}
		}	
		function forward_Info(){
		window.location='http://localhost/project/admin/settings_user.php';
		}
		function forward_logout(){
            var doc;
            var result = confirm("Do you really want to logout!");
            if (result == true) {
                window.location='http://localhost/project/admin/logout.php';
            } else {
              
            }
		}
		function forward_home(){
			window.location='http://localhost/project/admin/home.php';
		}
	</script>
	
</html>
