<?php

require 'master.php';
 
?>

<head>
<link rel="stylesheet"  href="../css/dots.css">
<link rel="stylesheet"  href="../css/users.css">
</head>

<div class="rightcolumn">
<?php
			
					if(isset($_POST['delete'])){
						$userid=$_POST['userid'];
						 deleteUser($userid);
					}
						?>
<section id="reports" >
<div class="card" style="height:20%">
						<h2 style="float:left">Users</h2>
						<form action="" method="post" >
							<div  style="float:right">
								<input type="text" name="search" id="val" placeholder="search user" onkeyup="searchFun_one(0,'val')" style="width:300px">
							</div>
						</form>
						</div>
							<div class="row" id="cont" style="height:400px; padding:5%;overflow-x:scroll; overflow-x: hidden;background-color:lightgrey;border-radius:5px;">
								<?php
									$sql="select * from user where isdel=1;";
									$result=$con->query($sql);
									if($result->num_rows>0){
										?>
											<table cellpadding=10 align="center" style="width:100%" id="myTable" >
										<?php
										while($row=$result->fetch_assoc()){?>
										<tr>
											<td>
											<table  cellpadding=10 class='users' name="" onclick="document.getElementById('<?php echo $row['user_id'] ?>').style.display='block';">
											<tr>
											<td style='width:40%'><?php echo $row['uname']?></td>
											</tr>
											</table>
											<div id='<?php echo $row['user_id'] ?>' class='modal' > 
											<form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"method="post"  enctype="multipart/form-data" style="height:80%;width:75%;">
												<div class="imgcontainer">
												   <span onclick="document.getElementById('<?php echo $row['user_id'] ?>').style.display='none'" class="rarr" >&larr;</span>
												</div>
												<fieldset style="margin-top:50px;background-color:linen">
												<legend style="margin-left:10%"><h2 align="center"><?php echo $row['uname']?></h2></legend>
												<div class="container" style="height:60%;overflow-x:scroll; overflow-x: hidden;">
												<div class="row">
												<div style="width:49%;float:left;">
													<table  cellpadding=10 class='users' style="width:50%" onclick="document.getElementById('crimes').style.display='block';">
														<tr>
														<td style='width:80%'>reported Crimes</td>
														<td><?php counter("crime_id","crime","user_id",$row['user_id'])?></td>
														</tr>
													</table><br>
													<table  cellpadding=10 class='users' style="width:50%" onclick="document.getElementById('crimes').style.display='block';">
														<tr>
														<td style='width:80%'>Feedbacks</td>
														<td><?php counter("feedback_id","feedback","user_id",$row['user_id'])?></td>
														</tr>
													</table>
												</div>												
												<div style="width:49%;float:left;margin-left:2%;">
													<table  cellpadding=10 class='users' style="width:50%" onclick="document.getElementById('crimes').style.display='block';">
														<tr>
														<td style='width:80%' onclick=""><input type="hidden" name="userid" value="<?php echo $row['user_id'];?>">
															<button name="delete"  style="padding:5px;width:100px"><img src="../images/icons/delete_icon.png" alt="Person" style="width:50px;height:50px;"> </button>	</td>
														</tr>
													</table><br>
													
												</div>
												</div>
												<br>
												
												 
														</div>  
														</fieldset>		
												  </form>
												</div>
												</td>
												</tr>
											<?php
												}
													}
									else{
										echo "No users found...";
									}
								?>
							</div>
</div>									
</section>
</div>	
<script>
function searchFun_one(var1,var2)
	{
		let filter = document.getElementById(var2).value; 

		let myTable = document.getElementById('myTable');

		let tr = myTable.getElementsByTagName('tr');

		for(var i=0; i<tr.length; i++)
		{
			let td = tr[i].getElementsByTagName('td')[var1];
			
			if(td)
			{
				let textvalue = td.textContent || td.innerHTML;
				if(textvalue.indexOf(filter) > -1)
				{
					tr[i].style.display = "";
				}
				else
				{
					tr[i].style.display="none";
				}
			}
		}
	}</script>