<?php
require '../library/pageFunction.php';
require 'master.php';

?>
<head>
<link rel="stylesheet"  href="../css/dots.css">
<style>
.dark{
	background-color:lightgrey;
}
</style>
</head>

<div class="rightcolumn">
			<section id="reports" >
					<div class="card">
				
						<h3 align="center">Crime Reports Data</3>
						</div>
						<div >
						<label for='myInput' >Crime_status</label>
						<select id="myInput" onchange="searchFun_one(5,'myInput')" style="width:10%;">
						<option value="">Select</option>
							<option>Verified</option>
							<option>Processing</option>
							<option>Failed</option>
						</select>
						<label for='myInput_city' style="margin-left:50px">Location</label>
						<select id="myInput_city" onchange="searchFun_one(2,'myInput_city')" style="width:15%;">
							<option value="">Select</option>
							<option>Ahmedabad</option>
							<option>Surat</option>	
							<option>Vadodara</option>	
							<option>Rajkot</option>
							<option>Bhavnagar</option>	
							<option>Jamnagar</option>	
							<option>Gandhinagar</option>
							<option>Junagadh</option>	
							<option>Gandhidham</option>
							<option>Anand</option>	
							<option>Navsari</option>	
							<option>Morbi</option>	
							<option>Nadiad</option>	
							<option>Surendranagar</option>		
							<option>Bharuch</option>	
							<option>Mehsana</option>	
							<option>Bhuj</option>
							<option>Porbandar</option>	
							<option>Palanpur</option>
							<option>Valsad</option>		
							<option>Vapi</option>	
							<option>Gondal</option>		
							<option>Veraval</option>	
							<option>Godhra</option>		
							<option>Patan</option>	
							<option>Kalol</option>	
							<option>Dahod</option>	
							<option>Botad</option>	
							<option>Amreli</option>	
							<option>Deesa</option>		
							<option>Jetpur</option>
						</select>
						<label for='myInput_city' style="margin-left:50px">Complaint_status</label>
						<select id="myInput_comp" onchange="searchFun_one(4,'myInput_comp')" style="width:10%;">
						<option value="">Select</option>
							<option>Filed</option>
							<option>pending</option>
							
						</select>
						<label for='myInput_del' style="margin-left:50px">Deleted</label>
						<select id="myInput_del" onchange="searchFun_one(6,'myInput_del')" style="width:10%;">
						<option value="">Select</option>
							<option>Yes</option>
							<option>No</option>
						</select>
						<button onclick="refresh()" style="width:%">Clear selection</button>
						</div>
						<div style="height:auto;border-top:3px solid grey;padding:5px;">
						 <?php
				
								$sql = "SELECT * from crime where isdel=1";
								$result= $con->query($sql);
								if($result->num_rows>0)
								{
								?><table cellpadding=10 align="center" style="width:100%" id="myTable" >
								<tr style="color:brown" class="dark">
									<th>Crime Title</th>
									<th>Crime details</th>
									<th>Crime Location</th>
									<th>Crime date</th>
									<th>Complaint Status</th>
									<th>Crime Status</th>
									<th>Deleted</th>
									<th>posting date</th>
								</tr>
								
								<?php
									while($row=$result->fetch_assoc()){
										?>
										
										<tr align="center"  >
										<td><?php echo $row['crime_title'];?></td>
										<td style="width:200px"><?php echo $row['crime_details'];?></td>
										<td><?php echo $row['crime_location'];?></td>
										<td><?php echo $row['crime_date'];?></td>
										<td><?php 
											if($row['complaint_status']==0){
												echo "<span style='color:green'>Filed</span>";
											}
											else{
												echo "<span style='color:red'>pending</span>";
											};?></td>
										<td><?php
											if($row['crime_status']=='v'){
												echo "<span style='color:green'>verified</span>";
											}
											else if($row['crime_status']=='p'){
												echo "<span style='color:'brown'>processing</span>";
											}
											else{
												echo "<span style='color:red'>Failed</span>";
											}
											;?></td>
										<td><?php
											if ($row['isdel']==0){
												echo "Yes";
											}
											else{
												echo "No";
											}
											;?></td>
										<td><?php echo $row['posting_date'];?></td>
										</tr>
										<?php
									}
								?></table><?php
								}
								
								?>
						</div>
		</section>
</div>
<script>
function searchFun_one(var1,var2)
	{
		let filter = document.getElementById(var2).value.toUpperCase(); 

		let myTable = document.getElementById('myTable');

		let tr = myTable.getElementsByTagName('tr');

		for(var i=1; i<tr.length; i++)
		{
			let td = tr[i].getElementsByTagName('td')[var1];
			
			if(td)
			{
				let textvalue = td.textContent || td.innerHTML;
				if(textvalue.toUpperCase().indexOf(filter) > -1)
				{
					tr[i].value= tr;
				}
				else
				{
					tr[i].style.display="none";
				}
			}
		}
	}
function refresh(){
		window.location='http://localhost/project/admin/report.php';
	}
</script>


