<?php
	require '../database/database.php';
	require '../library/lib.php';
	if(isset($_SESSION['admin'])){
		header("Location: http://localhost/project/admin/home.php");
	}
?>
<html>
<head>
<title>Trinetra Admin-login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="../css/index.css">
</head>
<body>
<?php

if (isset($_POST['btnlogin'])) {
	
			$uname=test_input($_POST['uname']);
			$password=test_input($_POST['password']);
		
				if("admin"== $uname && "admin"==$password){					
					$_SESSION['admin']=$uname;
					
					header("Location: home.php");
				}
				else{
					loginDiv($uname,$password);
				}
			}
?>
	<form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" style="height:auto;">
    <div class="imgcontainer">
      
      <!--<img src="img_avatar2.png" alt="Avatar" class="avatar">-->
    </div>
	<h2 align="center">Headquarters login</h2>
    <div class="container"> 
      <input type="text" placeholder="Enter Username" name="uname" required autocomplete="off">
      <input type="password" placeholder="Enter Password" name="password" required>
      <button name="btnlogin">Login</button>   
    </div>   
  </form>
<script src="modalcl.js"></script>
</body>
</html>