<?php

require 'master.php';
 
?>

<head>
<link rel="stylesheet"  href="../css/dots.css">

</head>

<div class="rightcolumn">
			<section id="reports" >
					<div class="card">
						<h2>Welcome, Admin</h2>
						</div>
						<div style="height:auto;border-top:3px solid grey;padding:5px;">
						<?php
							$sql_count="select count(user_id) from user where isdel=1";
							$result= $con->query($sql_count);
								if($result->num_rows>0)
								{
									$row=$result->fetch_assoc();
									$no_of_users= $row['count(user_id)'];
								}
						?>
										<table cellpadding=30 class='report'  style="width:auto" onclick="forward()">
										<tr>
										<td style='width:40%'><?php echo "Users";?></td>
										<td style='text-align:center'>
										<?php echo  $no_of_users;?>
										</td>
										</tr>
										</table><?php
										$odate="" ;
										$newDate = date("d-m-Y", strtotime($odate));
										?>
						<?php
							$sql_count="select count(dept_id) as d from dept ";
							$result= $con->query($sql_count);
								if($result->num_rows>0)
								{
									$row=$result->fetch_assoc();
									$no_of_dept= $row['d'];
								}
						?>
										<table cellpadding=30 class='report'  style="width:auto" onclick="forward_dept()">
										<tr>
										<td style='width:40%'><?php echo "Departments";?></td>
										<td style='text-align:center'>
										<?php echo  $no_of_dept;?>
										</td>
										</tr>
										</table><?php
										$odate="" ;
										$newDate = date("d-m-Y", strtotime($odate));
										?>
										
						</div>
		</section>
</div>
<script src="../javascript/slideshow.js"></script>
<script>
	function forward(){
		window.location='http://localhost/project/admin/users_list.php';
	
	}
	function forward_dept(){
		window.location='http://localhost/project/admin/dept_list.php';
	
	}
</script>

