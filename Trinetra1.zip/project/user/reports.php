<?php
require '../vendor/autoload.php'; // Load PHPMailer
require '../library/pageFunction.php';
require 'master.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Function to send email notifications
function sendEmailNotification($crimeid, $suser_id) {
    global $con;
    $stmt = $con->prepare("SELECT crime_title, crime_details, crime_location FROM crime WHERE crime_id = ?");
    $stmt->bind_param('i', $crimeid);
    $stmt->execute();
    $result = $stmt->get_result();
    $crime = $result->fetch_assoc();

    // Fetch user details from the database (assuming you have a users table)
    $stmtUser = $con->prepare("SELECT email, uname FROM user WHERE user_id = ?");
    $stmtUser->bind_param('i', $suser_id);
    $stmtUser->execute();
    $resultUser = $stmtUser->get_result();
    $user = $resultUser->fetch_assoc();

    // Initialize PHPMailer
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                      // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                 // Set the SMTP server
        $mail->SMTPAuth   = true;                             // Enable SMTP authentication
        $mail->Username   = '235300694044.pradip@gmail.com';           // Your Gmail address
        $mail->Password   = 'wnxb skft tphq qfyx';                  // Gmail password or app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;      // Enable SSL encryption
        $mail->Port       = 465;                              // TCP port for SSL

        //Recipients
        $mail->setFrom($user['email'], 'Crime Report System');
        $mail->addAddress($user['email'], 'Admin');      // Admin email

        // Content
        $mail->isHTML(true);
        $mail->Subject = "Feedback on Your {$crime['crime_title']} Recent Submission";
        $mail->Body    = "
            <h1>Dear {$user['uname']},</h1>
			<h6>
				Thank you for submitting a report through our crime reporting system. We understand the urgency of such incidents and appreciate your effort in providing critical information regarding the kidnapping case.</h6>

<h6>Here’s some feedback on your report to help ensure that the appropriate actions are taken swiftly:</h6>

<h6>Positive Feedback: The location and time of the incident you provided were very precise. This information is essential and will assist law enforcement in narrowing down the search area.</h6>

<h6>Constructive Feedback: We noticed that the description of the victim and the suspect was somewhat limited. If you have more information, such as their height, clothing, or any other distinguishing characteristics (tattoos, scars, etc.), please consider updating the report. These details are crucial in identifying and finding the individuals involved.</h6>

<h6>Encouragement: We encourage you to keep us informed if you come across any additional details or updates about the case. You can easily log back into the system and update the report with new information. Your prompt action can make a significant difference in resolving the case.</h6>

<h6>If you need assistance or have any questions, please don’t hesitate to contact us. Your vigilance is invaluable, and rest assured, this matter is receiving our immediate attention.</h6>

<h6>Thank you once again for your support.</h6>

<h6>Best regards,</h6>
<h6>{$crime['crime_location']}</h6>
<h6>Crime Reporting Team</h6>
<h6>City Crime Reporting System</h6>
			</p>
            <p><strong>Crime Title:</strong> {$crime['crime_title']}</p>
            <p><strong>Crime Details:</strong> {$crime['crime_details']}</p>
            <p><strong>Location:</strong> {$crime['crime_location']}</p>
            <p><strong>Reported By:</strong> {$user['uname']}</p>
            <p><strong>User Email:</strong> {$user['email']}</p>
        ";

        // Send the email
        $mail->send();
        echo 'Notification email has been sent!';
    } catch (Exception $e) {
        echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
<head>
<link rel="stylesheet"  href="../css/dots.css">
<style>
.row h3{
	color:brown;
}
</style>
</head>

<div class="rightcolumn">
			<section id="reports" >
					<div class="card">
					<?php
					 $suser_id=$_SESSION['user_id'];
					
					if(isset($_POST['comment'])){
						$crimeid=$_POST['crimeid'];
						$content=$_POST['content'];
						writeComment($suser_id,$crimeid,$content);
						sendEmailNotification($crimeid, $suser_id);
					}
					if(isset($_POST['file_comp'])){
						$crimeid=$_POST['crimeid'];
						file_complaint($crimeid,);
						sendEmailNotification($crimeid, $suser_id);
					}
					
					if(isset($_POST['delete'])){
						$crimeid=$_POST['crimeid'];
						 deleteCrime($crimeid);
						 sendEmailNotification($crimeid, $suser_id);
					}
					$sql_count="select count(crime_id) from crime where user_id=$suser_id and isdel=1";
							$result= $con->query($sql_count);
								if($result->num_rows>0)
								{
									$row=$result->fetch_assoc();
									$no_of_crime= $row['count(crime_id)'];
								}
								
	?>
						<p>Reported Crimes</p><?php echo "Records found:".$no_of_crime;?>
						</div>
						<div style="height:auto;border-top:3px solid grey;padding:5px;">
						 <?php						 
								$sql = "SELECT * from crime where user_id=$suser_id and isdel=1";
								$result= $con->query($sql);
								if($result->num_rows>0)
								{
									
								while($row=$result->fetch_assoc()){
										$crimeid=$row['crime_id'];
										$cmt="cmt".$row['crime_id'];
										$crime="crime".$row['crime_id'];
										$resp="resp".$row['crime_id'];
										$crime_location=$row['crime_location'];
										$sql_dept="select dept_id as did from dept where dname='$crime_location'";
										$result_dept= $con->query($sql_dept);
										if($result_dept->num_rows>0)
										{
											$row_dept=$result_dept->fetch_assoc();
											$dept_id=$row_dept['did'];
										}
										?><table class='report' onclick="document.getElementById('<?php echo $crime;?>').style.display='block';">
										<tr>
										<td style='width:40%'><?php echo $row['crime_title']; ?></td>
										<td style='margin-top:10px;float:right'>
										<div class="chip" style="width:35px;height:45px;background-color:transparent">
											<a onclick="document.getElementById('<?php echo $crime;?>').style.display='block';" ><img src="../images/icons/expand.png" alt="Person" style="width:35px;height:35px;margin-top:3px;"></a>
										</div>
										
										</td>
										</tr>
										</table>
										<?php
										$odate= $row["crime_date"];
										$newDate = date("d-m-Y", strtotime($odate));
										?>
										<div id='<?php echo $crime ?>' class='modal'> 
											<form class="modal-content animate" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"method="post"  enctype="multipart/form-data" style="margin:auto;height:auto;width:70%">
												
												   <span onclick="document.getElementById('<?php echo $crime ?>').style.display='none'" class="rarr" style="position:relative;">&larr;</span>
												
												<div style="padding:10px;">
													<fieldset>
													<legend><h2 align="center"><?php echo $row['crime_title']?></h2></legend>
													<div class="container">
													<div class="row">
													<div style="width:49%;float:left;">
													
													  <h3>User name</h3>
													  <span><?php echo $suname?></span>
													  <h3>Crime Details</h3>
														<span><?php echo $row['crime_details']?></span>
														<h3>Crime Location</h3>
														<p><?php echo $row['crime_location']?></p>	
													</div>												
													<div style="width:49%;float:left;margin-left:2%;">
														<h3 >Crime Date</h3>
														<p><?php echo $newDate?></p>
														<h3 >Reporing Date</h3>
														<p><?php echo $row['posting_date']?></p>
														<h4><?php if($row['complaint_status']==0){?>
																	<p style="color:green;">Complaint Filed</p><?php
																	}
																	else{?>
																	<p style="color:red;float:left">Complaint not filed!!</p>	<button name="file_comp"  style="padding:5px;width:70px"> File Now</button>	<?php
																	}
														?></h4>
														<h4 align="right"><?php if($row['crime_status']=="p"){?>
																		<div class="chip" style="background-color:white">
																		<img src="../images/icons/progress.png" alt="Person" onclick="document.getElementById('<?php echo $resp;?>').style.display='block';" style="cursor:pointer">
																		<span style="color:red">Processing..</span>
																		</div><?php
																	}
																	elseif ($row['crime_status']=="v"){?>
																		<div class="chip" style="background-color:white">
																		<img src="../images/icons/verified.png" alt="Person" onclick="document.getElementById('<?php echo $resp;?>').style.display='block';" style="cursor:pointer">
																		<span style="color:green">Verified</span>
																		</div><?php																	}
																	else{?>
																		<div class="chip" style="background-color:white">
																		<img src="../images/icons/failed.png" alt="Person" onclick="document.getElementById('<?php echo $resp;?>').style.display='block';" style="cursor:pointer">
																		<span style="color:red">Failed</span>
																		</div><?php	
																	}
														?></h4>	
													</div>
													<hr/>
													<input type="hidden" name="crimeid" value="<?php echo $crimeid;?>">
														<button name="delete"  style="padding:5px;width:70px"><img src="../images/icons/delete_icon.png" alt="Person" style="width:40px;height:40px;"> </button>	
														<div class="chip" style="width:20px">
														<img src="../images/icons/c.png" alt="Person" onclick="document.getElementById('<?php echo $cmt;?>').style.display='block';" style="cursor:pointer">
														</div>	
														<div class="chip" style="width:20px">
														<img src="../images/icons/response.png" alt="Person" onclick="document.getElementById('<?php echo $resp;?>').style.display='block';" style="cursor:pointer">
														</div>
													</div>
													<br>
													</div>  
													</fieldset>	
												</div>												
										  </form>
										</div>
										
										<div id='<?php echo $cmt ?>' class='modal'>
											  <form class='modal-content animate' action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method='post' style='margin:auto;height:350px;margin-top:10%;'>
												<div class='imgcontainer'>
												   <span onclick="document.getElementById('<?php echo $cmt;?>').style.display='none';" class='rarr' >&larr;</span>
												</div>
												<h2 align='center'>Comment</h2>
												<div class='container' style="height:150px;overflow-x:scroll; overflow-x: hidden;background-color:grey;">
													<?php
													comments($row['user_id'],$crimeid,$suser_id);
													?>		
													
												</div>
												<input type="text" name="content" placeholder="Write comment" >
													<button  name="comment">post</button>
													<input type='hidden' name='crimeid' value="<?php echo $crimeid?>" hidden >
											  </form>
										</div>
										<div id='<?php echo $resp ?>' class='modal'>
											  <form class='modal-content animate' action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method='post' style='margin:auto;height:350px;margin-top:10%;'>
												<div class='imgcontainer'>
												   <span onclick="document.getElementById('<?php echo $resp;?>').style.display='none';" class='rarr' >&larr;</span>
												</div>
												<h2 align='center'>Response</h2>
												<div class='container' style="height:250px;overflow-x:scroll; overflow-x: hidden;">
													<?php
													
													response($dept_id,$crimeid);
													?>		
													
												</div>
												
											  </form>
										</div>
										<?php
									}
								}
								else{
									$err= "now record found!!";
								}
								?>
						</div>
		</section>
</div>
<script>
</script>